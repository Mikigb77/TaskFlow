import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:agenda/screens/home_screen.dart';
import 'package:agenda/screens/completed_tasks_screen.dart';
import 'package:agenda/screens/create_task_screen.dart';
import 'package:agenda/screens/calendar_screen.dart';
import 'package:agenda/screens/edit_task_screen.dart'; // Import the edit task screen
import 'package:flutter_local_notifications/flutter_local_notifications.dart'; // Import for local notifications
import 'package:timezone/data/latest.dart' as tz; // Import for timezone setup
import 'package:agenda/services/notification_service.dart'; // Import the notification service

// Notification plugin initialization
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize timezone
  tz.initializeTimeZones();

  // Notification settings for Android
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('app_icon');

  // Initialize settings for notifications
  final InitializationSettings initializationSettings =
      InitializationSettings(android: initializationSettingsAndroid);

  // Initialize notifications
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  // Schedule the notifications
  await scheduleMorningNotification();
  await scheduleEveningNotification();

  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Agenda',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[900], // Dark theme background
        textTheme: const TextTheme(
          bodyMedium:
              TextStyle(color: Colors.white), // White text for readability
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/home': (context) => const HomeScreen(),
        '/completedTasks': (context) => const CompletedTasksScreen(),
        '/createTask': (context) => const CreateTaskScreen(),
        '/calendar': (context) => const CalendarScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/editTask') {
          final int taskId = settings.arguments as int;
          return MaterialPageRoute(
            builder: (context) => EditTaskScreen(taskId: taskId),
          );
        }
        return null;
      },
    );
  }
}
