import 'package:agenda/providers/task_provider.dart';
import 'package:agenda/widgets/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:agenda/utils/constants.dart';
import 'package:intl/intl.dart';
import 'package:agenda/screens/edit_task_screen.dart';

class TaskDetailScreen extends ConsumerWidget {
  final int taskId;

  const TaskDetailScreen({super.key, required this.taskId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final taskState = ref.watch(taskProvider);

    return taskState.when(
      data: (tasks) {
        final task = tasks.firstWhere((task) => task.id == taskId);

        return Scaffold(
          appBar: _buildAppBar(context),
          backgroundColor: defaultBackgroundColor,
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSection(
                  title: 'Due Date',
                  content: DateFormat('dd/MM/yyyy').format(task.dueDate),
                  icon: Icons.calendar_today,
                  iconColor: Colors.grey, // Softer color for the due date icon
                ),
                _buildSection(
                  title: 'Time',
                  content: DateFormat('HH:mm').format(task.dueDate),
                  icon: Icons.access_time,
                  iconColor: Colors.lightBlueAccent,
                ),
                _buildSection(
                  title: 'Priority',
                  content: _priorityToString(task.priority),
                  icon: Icons.priority_high,
                  iconColor: _getPriorityColor(task.priority),
                ),
                _buildNotesSection(task.notes),
              ],
            ),
          ),
          floatingActionButton: _buildFloatingActionButton(context, ref),
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (error, stackTrace) => Center(
        child: Text(
          'Error: $error',
          style: const TextStyle(color: Colors.red, fontSize: 18),
        ),
      ),
    );
  }

  CustomAppBar _buildAppBar(BuildContext context) {
    return const CustomAppBar(title: "Task Details");
  }

  Widget _buildSection({
    required String title,
    required String content,
    required IconData icon,
    required Color iconColor,
  }) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      color: cardColor,
      elevation: 3,
      child: ListTile(
        leading: Icon(icon, color: iconColor),
        title: Text(
          title,
          style: TextStyle(
            color: textColor,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          content,
          style: TextStyle(
            color: subtitleTextColor,
            fontSize: 16.0,
          ),
        ),
      ),
    );
  }

  Widget _buildNotesSection(String? notes) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10.0),
      ),
      color: cardColor,
      elevation: 3,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Notes',
              style: TextStyle(
                color: textColor,
                fontSize: 18.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8.0),
            Text(
              notes ?? 'No notes added',
              style: TextStyle(
                color: subtitleTextColor,
                fontSize: 16.0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingActionButton(BuildContext context, WidgetRef ref) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        FloatingActionButton(
          heroTag: 'edit',
          backgroundColor: Colors.grey, // Softer color for the edit button
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => EditTaskScreen(taskId: taskId),
              ),
            );
          },
          child: const Icon(Icons.edit, color: Colors.white),
        ),
        const SizedBox(width: 16),
        FloatingActionButton(
          heroTag: 'delete',
          backgroundColor: Colors.red, // Softer color for the delete button
          onPressed: () {
            _confirmDelete(context, ref.read(taskProvider.notifier));
          },
          child: const Icon(Icons.delete, color: Colors.white),
        ),
      ],
    );
  }

  void _confirmDelete(BuildContext context, TaskNotifier taskNotifier) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Delete Task'),
          content: const Text('Are you sure you want to delete this task?'),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
              },
            ),
            TextButton(
              child: const Text('Delete', style: TextStyle(color: Colors.red)),
              onPressed: () {
                Navigator.of(context).pop(); // Dismiss the dialog
                taskNotifier.deleteTask(taskId); // Trigger deletion
                Navigator.of(context).pop(); // Navigate back after deletion
              },
            ),
          ],
        );
      },
    );
  }

  String _priorityToString(int priority) {
    switch (priority) {
      case 1:
        return 'Low';
      case 2:
        return 'Medium';
      case 3:
        return 'High';
      default:
        return 'Unknown';
    }
  }

  Color _getPriorityColor(int priority) {
    switch (priority) {
      case 1:
        return Colors.blueGrey;
      case 2:
        return Colors.amber;
      case 3:
        return Colors.deepOrange;
      default:
        return Colors.grey;
    }
  }
}
