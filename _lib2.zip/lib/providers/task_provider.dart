import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:agenda/models/task.dart';
import 'package:agenda/repositories/task_repository.dart';
import 'package:agenda/services/task_database.dart';

// Define a provider for TaskRepository
final taskRepositoryProvider = Provider<TaskRepository>((ref) {
  return TaskRepository(TaskDatabase());
});

// Define a StateNotifierProvider for managing tasks with AsyncValue
final taskProvider =
    StateNotifierProvider<TaskNotifier, AsyncValue<List<Task>>>((ref) {
  return TaskNotifier(ref.read(taskRepositoryProvider));
});

// TaskNotifier class to manage the state of the task list
class TaskNotifier extends StateNotifier<AsyncValue<List<Task>>> {
  final TaskRepository _taskRepository;

  TaskNotifier(this._taskRepository) : super(const AsyncValue.loading()) {
    loadTasks();
  }

  // Load tasks from the database
  Future<void> loadTasks() async {
    try {
      final tasks = await _taskRepository.getAllTasks();
      state = AsyncValue.data(tasks);
    } catch (e, stackTrace) {
      state = AsyncValue.error(
          e, stackTrace); // Correctly passing both error and stackTrace
    }
  }

  // Add a new task
  Future<void> addTask(Task task) async {
    try {
      await _taskRepository.addTask(task);
      loadTasks();
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  // Update an existing task
  Future<void> updateTask(Task task) async {
    try {
      await _taskRepository.updateTask(task);
      loadTasks();
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  // Delete a task
  Future<void> deleteTask(int id) async {
    try {
      await _taskRepository.deleteTask(id);
      loadTasks();
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }
}
