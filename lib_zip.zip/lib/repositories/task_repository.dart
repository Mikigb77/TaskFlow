import 'package:agenda/models/task.dart';
import 'package:agenda/services/task_database.dart';

class TaskRepository {
  final TaskDatabase _database;

  TaskRepository(this._database);

  Future<int> addTask(Task task) async {
    return await _database.insertTask(task);
  }

  Future<List<Task>> getAllTasks() async {
    return await _database.getTasks();
  }

  Future<int> updateTask(Task task) async {
    return await _database.updateTask(task);
  }

  Future<int> deleteTask(int id) async {
    return await _database.deleteTask(id);
  }
}
