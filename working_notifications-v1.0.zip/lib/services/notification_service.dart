import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:agenda/models/task.dart';
import 'package:agenda/providers/task_provider.dart'; // Import the provider for TaskRepository
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter/material.dart'; // Import TimeOfDay for time handling
import 'package:flutter_riverpod/flutter_riverpod.dart'; // Import for Riverpod

// Notification plugin initialization
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

// Schedule Morning Notification at 8:00 AM
Future<void> scheduleMorningNotification() async {
  final tasks = await getTasksForNextThreeDays();

  if (tasks.isNotEmpty) {
    String taskList = tasks
        .take(3)
        .map((task) =>
            "${task.title}: due in ${task.dueDate.difference(DateTime.now()).inDays} days")
        .join(", ");

    await flutterLocalNotificationsPlugin.zonedSchedule(
      0,
      'Good Morning!',
      'Here are your upcoming tasks: $taskList',
      _nextInstanceOfTime(const TimeOfDay(hour: 8, minute: 0)), // 8:00 AM
      const NotificationDetails(
          android: AndroidNotificationDetails(
              'morning_channel', 'Morning Reminders')),
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}

// Schedule Evening Notification at 8:00 PM
Future<void> scheduleEveningNotification() async {
  final tasks = await getTasksForNextThreeDays();

  if (tasks.isNotEmpty) {
    String taskList = tasks
        .take(3)
        .map((task) =>
            "${task.title}: due in ${task.dueDate.difference(DateTime.now()).inDays} days")
        .join(", ");

    await flutterLocalNotificationsPlugin.zonedSchedule(
      1,
      'Evening Check-in',
      'Did you make progress on these tasks: $taskList? Consider rescheduling if needed.',
      _nextInstanceOfTime(const TimeOfDay(hour: 20, minute: 0)), // 8:00 PM
      const NotificationDetails(
          android: AndroidNotificationDetails(
              'evening_channel', 'Evening Reminders')),
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}

// Schedule Important Task Notification (10 minutes before due time)
Future<void> scheduleImportantTaskReminders() async {
  final container = ProviderContainer();
  final taskRepository = container.read(taskRepositoryProvider);

  final tasks = await taskRepository.getAllTasks();

  for (Task task in tasks) {
    if (task.priority == 1 && !task.isCompleted) {
      // Assuming priority 1 is "important"
      final tz.TZDateTime dueTime = tz.TZDateTime.from(task.dueDate, tz.local);
      final tz.TZDateTime reminderTime = dueTime
          .subtract(const Duration(minutes: 10)); // 10 minutes before due date

      if (reminderTime.isAfter(tz.TZDateTime.now(tz.local))) {
        await flutterLocalNotificationsPlugin.zonedSchedule(
          task.id!, // Use the task ID as notification ID
          'Important Task Due Soon!',
          'Your task "${task.title}" is due in 10 minutes.',
          reminderTime,
          const NotificationDetails(
            android: AndroidNotificationDetails(
                'important_channel', 'Important Task Reminders'),
          ),
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: DateTimeComponents.time,
        );
      }
    }
  }
}

// Helper function to fetch tasks due in the next three days
Future<List<Task>> getTasksForNextThreeDays() async {
  final container = ProviderContainer(); // Create a provider container
  final taskRepository = container
      .read(taskRepositoryProvider); // Access TaskRepository from provider

  final tasks =
      await taskRepository.getAllTasks(); // Fetch tasks from repository
  final now = DateTime.now();
  final threeDaysLater = now.add(const Duration(days: 3));

  return tasks.where((task) {
    return !task.isCompleted &&
        task.dueDate.isAfter(now) &&
        task.dueDate.isBefore(threeDaysLater);
  }).toList();
}

// Helper function to calculate the next notification instance for a given time
tz.TZDateTime _nextInstanceOfTime(TimeOfDay timeOfDay) {
  final tz.TZDateTime now = tz.TZDateTime.now(tz.local);
  tz.TZDateTime scheduledDate = tz.TZDateTime(
      tz.local, now.year, now.month, now.day, timeOfDay.hour, timeOfDay.minute);
  if (scheduledDate.isBefore(now)) {
    scheduledDate = scheduledDate.add(const Duration(days: 1));
  }
  return scheduledDate;
}
