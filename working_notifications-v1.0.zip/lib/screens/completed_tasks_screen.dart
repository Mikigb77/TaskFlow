import 'package:agenda/widgets/custom_app_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:agenda/widgets/task_list.dart';
import 'package:agenda/providers/task_provider.dart';
import 'package:agenda/utils/constants.dart';

class CompletedTasksScreen extends ConsumerWidget {
  const CompletedTasksScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final taskState = ref.watch(taskProvider);

    return Scaffold(
      appBar: const CustomAppBar(title: "Completed Tasks"),
      backgroundColor: defaultBackgroundColor,
      body: taskState.when(
        data: (tasks) {
          final completedTasks =
              tasks.where((task) => task.isCompleted).toList();
          if (completedTasks.isEmpty) {
            return const Center(
              child: Text(
                'No completed tasks.',
                style: TextStyle(color: Colors.white, fontSize: 18),
              ),
            );
          } else {
            return TaskList(tasks: completedTasks);
          }
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stackTrace) => Center(
          child: Text(
            'Error: $error',
            style: const TextStyle(color: Colors.red, fontSize: 18),
          ),
        ),
      ),
    );
  }
}
