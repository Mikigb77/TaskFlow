import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:agenda/screens/home_screen.dart';
import 'package:agenda/screens/completed_tasks_screen.dart';
import 'package:agenda/screens/create_task_screen.dart';
import 'package:agenda/screens/calendar_screen.dart';
import 'package:agenda/screens/edit_task_screen.dart'; // Import the edit task screen
import 'package:flutter_local_notifications/flutter_local_notifications.dart'; // Import for local notifications
import 'package:timezone/data/latest.dart' as tz; // Import for timezone setup
import 'package:timezone/timezone.dart' as tz;
import 'package:agenda/services/notification_service.dart'; // Import the notification service
import 'package:permission_handler/permission_handler.dart'; // Import for permission handling
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart'; // Import device_info_plus for Android version check

// Notification plugin initialization
final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize timezone
  tz.initializeTimeZones();

  // Notification settings for Android
  const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('app_icon');

  // Initialize settings for notifications
  const InitializationSettings initializationSettings =
      InitializationSettings(android: initializationSettingsAndroid);

  // Request notification permissions for Android 13+ (API level 33+)
  if (Platform.isAndroid && await _isAndroid13OrAbove()) {
    await _requestNotificationPermissionForAndroid13();
  }

  // Request exact alarm permission for Android 12+ (API level 31+)
  if (Platform.isAndroid && await _isAndroid12OrAbove()) {
    await _requestExactAlarmPermission();
  }

  // Initialize notifications
  await flutterLocalNotificationsPlugin.initialize(initializationSettings);

  // Schedule the dummy notification
  //await scheduleDummyNotification();

  // Schedule the regular notifications
  await scheduleMorningNotification();
  await scheduleEveningNotification();

  runApp(
    const ProviderScope(
      child: MyApp(),
    ),
  );
}

// Function to schedule a dummy notification 30 seconds after app start
Future<void> scheduleDummyNotification() async {
  await flutterLocalNotificationsPlugin.zonedSchedule(
    0,
    'Test Notification',
    'This is a test notification scheduled 30 seconds from app start.',
    tz.TZDateTime.now(tz.local)
        .add(const Duration(seconds: 30)), // 30 seconds delay
    const NotificationDetails(
      android: AndroidNotificationDetails(
        'test_channel', // Create a test channel
        'Test Notifications',
        importance: Importance.max,
        priority: Priority.high,
      ),
    ),
    androidAllowWhileIdle: true,
    uiLocalNotificationDateInterpretation:
        UILocalNotificationDateInterpretation.absoluteTime,
    matchDateTimeComponents: DateTimeComponents.time,
  );
}

// Helper function to request notification permission for Android 13+
Future<void> _requestNotificationPermissionForAndroid13() async {
  var androidFlutterLocalNotificationsPlugin =
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();

  if (androidFlutterLocalNotificationsPlugin != null) {
    await androidFlutterLocalNotificationsPlugin
        .requestNotificationsPermission(); // Correct method name
  }
}

// Helper function to check if the device is running Android 13 or above
Future<bool> _isAndroid13OrAbove() async {
  final int sdkInt = await _getSdkInt();
  return sdkInt >= 33;
}

// Helper function to check if the device is running Android 12 or above
Future<bool> _isAndroid12OrAbove() async {
  final int sdkInt = await _getSdkInt();
  return sdkInt >= 31;
}

// Helper function to request the SCHEDULE_EXACT_ALARM permission
Future<void> _requestExactAlarmPermission() async {
  var androidFlutterLocalNotificationsPlugin =
      flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
  if (androidFlutterLocalNotificationsPlugin != null) {
    await androidFlutterLocalNotificationsPlugin.requestExactAlarmsPermission();
  }
}

// Helper function to get the Android SDK version
Future<int> _getSdkInt() async {
  if (Platform.isAndroid) {
    var androidInfo = await DeviceInfoPlugin().androidInfo;
    return androidInfo.version.sdkInt;
  }
  return 0;
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Agenda',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[900], // Dark theme background
        textTheme: const TextTheme(
          bodyMedium:
              TextStyle(color: Colors.white), // White text for readability
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const HomeScreen(),
        '/home': (context) => const HomeScreen(),
        '/completedTasks': (context) => const CompletedTasksScreen(),
        '/createTask': (context) => const CreateTaskScreen(),
        '/calendar': (context) => const CalendarScreen(),
      },
      onGenerateRoute: (settings) {
        if (settings.name == '/editTask') {
          final int taskId = settings.arguments as int;
          return MaterialPageRoute(
            builder: (context) => EditTaskScreen(taskId: taskId),
          );
        }
        return null;
      },
    );
  }
}
