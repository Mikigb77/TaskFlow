import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:agenda/models/task.dart';
import 'package:agenda/repositories/task_repository.dart';
import 'package:agenda/services/task_database.dart';
import 'package:agenda/services/notification_service.dart'; // Import for notifications
import 'package:timezone/timezone.dart' as tz;

// Define a provider for TaskRepository
final taskRepositoryProvider = Provider<TaskRepository>((ref) {
  return TaskRepository(TaskDatabase());
});

// Define a StateNotifierProvider for managing tasks with AsyncValue
final taskProvider =
    StateNotifierProvider<TaskNotifier, AsyncValue<List<Task>>>((ref) {
  return TaskNotifier(ref.read(taskRepositoryProvider));
});

// TaskNotifier class to manage the state of the task list
class TaskNotifier extends StateNotifier<AsyncValue<List<Task>>> {
  final TaskRepository _taskRepository;

  TaskNotifier(this._taskRepository) : super(const AsyncValue.loading()) {
    loadTasks();
  }

  // Load tasks from the database
  Future<void> loadTasks() async {
    try {
      final tasks = await _taskRepository.getAllTasks();
      state = AsyncValue.data(tasks);
    } catch (e, stackTrace) {
      state = AsyncValue.error(
          e, stackTrace); // Correctly passing both error and stackTrace
    }
  }

  // Add a new task and schedule important task notifications
  Future<void> addTask(Task task) async {
    try {
      await _taskRepository.addTask(task);
      loadTasks(); // Refresh the task list

      // Schedule the important task reminder if the task is important
      if (task.priority == 1 && !task.isCompleted) {
        final tz.TZDateTime dueTime =
            tz.TZDateTime.from(task.dueDate, tz.local);
        final tz.TZDateTime reminderTime = dueTime.subtract(
            const Duration(minutes: 10)); // 10 minutes before due time

        if (reminderTime.isAfter(tz.TZDateTime.now(tz.local))) {
          await flutterLocalNotificationsPlugin.zonedSchedule(
            task.id!, // Use task ID for the notification ID
            'Important Task Due Soon!',
            'Your task "${task.title}" is due in 10 minutes.',
            reminderTime,
            const NotificationDetails(
              android: AndroidNotificationDetails(
                  'important_channel', 'Important Task Reminders'),
            ),
            uiLocalNotificationDateInterpretation:
                UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.time,
          );
        }
      }
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace); // Handle errors
    }
  }

  // Update an existing task
  Future<void> updateTask(Task task) async {
    try {
      await _taskRepository.updateTask(task);
      loadTasks();
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }

  // Delete a task
  Future<void> deleteTask(int id) async {
    try {
      await _taskRepository.deleteTask(id);
      loadTasks();
    } catch (e, stackTrace) {
      state = AsyncValue.error(e, stackTrace);
    }
  }
}
